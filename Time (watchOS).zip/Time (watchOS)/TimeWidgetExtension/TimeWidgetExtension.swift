// Delete entire file contents
