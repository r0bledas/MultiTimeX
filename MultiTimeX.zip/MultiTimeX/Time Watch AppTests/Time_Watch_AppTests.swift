//
//  Time_Watch_AppTests.swift
//  Time Watch AppTests
//
//  Created by Raudel Alejandro on 07-02-2025.
//

import Testing
@testable import Time_Watch_App

struct Time_Watch_AppTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
