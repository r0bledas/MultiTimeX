//
//  MultiTimeXTests.swift
//  MultiTimeXTests
//
//  Created by Raudel Alejandro on 23-03-2025.
//

import Testing

struct MultiTimeXTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
