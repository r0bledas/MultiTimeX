//
//  MultiTimeXApp.swift
//  MultiTimeX
//
//  Created by Raudel Alejandro on 23-03-2025.
//

import SwiftUI

@main
struct MultiTimeXApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
