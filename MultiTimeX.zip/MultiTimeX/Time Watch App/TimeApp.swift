//
//  TimeApp.swift
//  Time Watch App
//
//  Created by Raudel Alejandro on 07-02-2025.
//

import SwiftUI

@main
struct Time_Watch_AppApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
